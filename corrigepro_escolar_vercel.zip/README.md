# CorrigePro Escolar

Aplicação web estática para publicar no Vercel.

## Inclui
- Configuração da prova, quantidade de questões e alternativas A-D/A-E.
- Digitação do gabarito por texto (ex.: `1 B, 2 D`) ou pela grade.
- Cadastro de turmas/salas e alunos com número de chamada; importação em lote.
- Geração de PDF A4 com uma folha por aluno, incluindo QR de identificação e bolhas.
- Upload de imagem da folha e tentativa de identificação automática via QR code.
- Conferência manual das respostas, cálculo de acertos/erros/brancos/nota.
- Relatório de resultados por turma em CSV e PDF, impressão e backup JSON.
- Dados persistidos no armazenamento local do navegador.

## Publicar
1. Extraia o ZIP.
2. Envie `index.html` e `vercel.json` para um repositório GitHub.
3. No Vercel, escolha **Add New → Project**, importe o repositório e faça Deploy.
4. Não precisa de comando de build.

## Limitações importantes
- O app é uma versão estática: os dados ficam no navegador do dispositivo e não sincronizam entre computadores/contas. Faça backup JSON regularmente.
- A identificação do aluno por QR depende de a imagem conter o QR impresso e de a biblioteca de QR estar acessível.
- A leitura inicial das bolhas usa posições fixas da folha A4 e pressupõe a página inteira, reta e quase sem perspectiva. Pode falhar em fotos inclinadas, cortadas, sombreadas ou com marcações fracas. Sempre confira as respostas detectadas antes de salvar notas oficiais; uma solução robusta para fotos arbitrárias exige correção de perspectiva/OMR e testes com folhas reais.
- As bibliotecas de PDF e QR são carregadas de CDNs, então a primeira abertura/publicação precisa de internet.
